/**
 * Data models used across the application.
 */
package scheduleapp.model;
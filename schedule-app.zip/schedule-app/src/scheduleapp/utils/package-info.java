/**
 * Contains tools to access resources, logs and handles unique controls.
 */

package scheduleapp.utils;
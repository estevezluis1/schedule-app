/**
 * Controllers for our views.
 */
package scheduleapp.controller;
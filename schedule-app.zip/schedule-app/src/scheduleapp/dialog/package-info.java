/**
 * Dialog windows for this applications.
 */
package scheduleapp.dialog;